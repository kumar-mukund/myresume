
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/github-oauth.mjs
var CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type"
};
var github_oauth_default = async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: CORS_HEADERS });
  }
  if (req.method !== "GET") {
    return new Response(JSON.stringify({ error: "Only GET is supported" }), {
      status: 404,
      headers: { "Content-Type": "application/json", ...CORS_HEADERS }
    });
  }
  const url = new URL(req.url);
  const code = url.searchParams.get("code");
  if (!code) {
    return new Response(JSON.stringify({ error: "Missing code query param" }), {
      status: 400,
      headers: { "Content-Type": "application/json", ...CORS_HEADERS }
    });
  }
  const clientId = process.env.GITHUB_CLIENT_ID;
  const clientSecret = process.env.GITHUB_CLIENT_SECRET;
  if (!clientId || !clientSecret) {
    return new Response(JSON.stringify({ error: "GitHub sign-in is not configured on the server (missing GITHUB_CLIENT_ID / GITHUB_CLIENT_SECRET env vars)." }), {
      status: 500,
      headers: { "Content-Type": "application/json", ...CORS_HEADERS }
    });
  }
  try {
    const tokenRes = await fetch("https://github.com/login/oauth/access_token", {
      method: "POST",
      headers: { "Content-Type": "application/json", "Accept": "application/json" },
      body: JSON.stringify({ client_id: clientId, client_secret: clientSecret, code })
    });
    const tokenBody = await tokenRes.json();
    if (!tokenRes.ok || !tokenBody.access_token) {
      return new Response(JSON.stringify({ error: tokenBody.error_description || "GitHub did not return an access token." }), {
        status: 400,
        headers: { "Content-Type": "application/json", ...CORS_HEADERS }
      });
    }
    const profileRes = await fetch("https://api.github.com/user", {
      headers: { "Authorization": `Bearer ${tokenBody.access_token}`, "User-Agent": "myresume-app" }
    });
    if (!profileRes.ok) {
      return new Response(JSON.stringify({ error: "Could not fetch the GitHub profile." }), {
        status: 502,
        headers: { "Content-Type": "application/json", ...CORS_HEADERS }
      });
    }
    const profile = await profileRes.json();
    return new Response(JSON.stringify({
      login: profile.login || "",
      name: profile.name || "",
      avatarUrl: profile.avatar_url || ""
    }), {
      status: 200,
      headers: { "Content-Type": "application/json", ...CORS_HEADERS }
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: "GitHub sign-in failed \u2014 please try again." }), {
      status: 502,
      headers: { "Content-Type": "application/json", ...CORS_HEADERS }
    });
  }
};
var config = {
  path: "/github-oauth"
};
export {
  config,
  github_oauth_default as default
};
